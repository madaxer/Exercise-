# TOS Compose Tool

Generated on 2025-04-18T10:59:45Z

## Quick start

```bash
# 1. generate a compose with modules 'multiplexor' and 'server'
python scripts/manage.py generate \
    --base docker-compose-base.yml \
    --modules-dir tos \
    --modules multiplexor server

# 2. bring it up
python scripts/manage.py deploy --compose docker-compose.generated.yml

# 3. and later tear it down
python scripts/manage.py destroy --compose docker-compose.generated.yml
```

`manage.py` is intentionally single‑file for easy invocation, while all
reusable logic lives under `compose_tool/`.
