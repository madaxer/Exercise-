"""Module descriptor → docker‑compose service mapper."""
from __future__ import annotations
import yaml
from pathlib import Path
from typing import Dict, Any, List

class Module:
    def __init__(self, yaml_path: Path):
        self.yaml_path = yaml_path
        self.raw: Dict[str, Any] = yaml.safe_load(self.yaml_path.read_text()) or {}
        self.name: str = self.raw.get("node_name") or self.yaml_path.parent.name

    # ----------- private helpers ------------------------------------
    def _image(self) -> str | None:
        img = self.raw.get("image")
        if isinstance(img, str):
            return img
        if isinstance(img, dict):
            repo = img.get("repository")
            tag  = img.get("tag", "latest")
            return f"{repo}:{tag}" if repo else None
        return None

    def _env(self) -> List[str]:
        env = self.raw.get("env", [])
        if isinstance(env, list):
            return [f"{e['name']}={e['value']}" for e in env if 'name' in e and 'value' in e]
        return []

    def _ports(self) -> List[str]:
        ports = []
        for p in self.raw.get("ports", []):
            c = p.get("containerPort")
            h = p.get("hostPort", c)
            if c:
                ports.append(f"{h}:{c}")
        return ports

    def _volumes(self) -> List[str]:
        return self.raw.get("volumes", []) or []

    # ----------- public API -----------------------------------------
    def compose_service(self) -> Dict[str, Any]:
        block: Dict[str, Any] = {
            "container_name": self.name,
            "image": self._image(),
            "environment": self._env(),
            "ports": self._ports(),
            "volumes": self._volumes(),
        }
        # drop falsy
        return {self.name: {k: v for k, v in block.items() if v}}

    def declared_named_volumes(self) -> List[str]:
        out = []
        for v in self._volumes():
            host = v.split(":")[0]
            if "/" not in host:
                out.append(host)
        return out
