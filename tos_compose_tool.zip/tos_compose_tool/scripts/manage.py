#!/usr/bin/env python3
"""Unified CLI to generate, deploy, or destroy TOS stack."""
from __future__ import annotations
import argparse, sys, pathlib
from compose_tool.module import Module
from compose_tool.builder import ComposeBuilder
from compose_tool import docker_utils

def collect_modules(mod_dir: pathlib.Path, names: list[str]) -> list[Module]:
    modules = []
    for n in names:
        m_path = mod_dir / n / "values.yaml"
        if not m_path.exists():
            sys.exit(f"Module '{n}' not found ({m_path})")
        modules.append(Module(m_path))
    return modules

def cmd_generate(args):
    base = pathlib.Path(args.base)
    out  = pathlib.Path(args.output)
    mod_dir = pathlib.Path(args.modules_dir)
    mods = collect_modules(mod_dir, args.modules)
    builder = ComposeBuilder(base)
    for m in mods:
        builder.add_module(m)
    out.write_text(builder.dump())
    print(f"✔ wrote {out}")

    if args.create_volumes:
        vols = [v for m in mods for v in m.declared_named_volumes()]
        docker_utils.create_named_volumes(vols)

def cmd_deploy(args):
    docker_utils.run_compose(args.compose, "up")

def cmd_destroy(args):
    docker_utils.run_compose(args.compose, "down")

# -------------- CLI plumbing ---------------------------------------
def main(argv=None):
    p = argparse.ArgumentParser(prog="tosctl", description="TOS compose helper")
    sub = p.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("generate", help="render docker-compose from modules")
    g.add_argument("--base", required=True)
    g.add_argument("--modules-dir", default="tos")
    g.add_argument("--modules", required=True, nargs="+", help="module names")
    g.add_argument("--output", default="docker-compose.generated.yml")
    g.add_argument("--create-volumes", action="store_true")
    g.set_defaults(func=cmd_generate)

    d = sub.add_parser("deploy", help="docker compose up -d")
    d.add_argument("--compose", default="docker-compose.generated.yml")
    d.set_defaults(func=cmd_deploy)

    r = sub.add_parser("destroy", help="docker compose down")
    r.add_argument("--compose", default="docker-compose.generated.yml")
    r.set_defaults(func=cmd_destroy)

    args = p.parse_args(argv)
    args.func(args)

if __name__ == "__main__":
    main()
