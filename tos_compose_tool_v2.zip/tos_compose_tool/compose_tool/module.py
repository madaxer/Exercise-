"""Module descriptor → docker‑compose service mapper (multi‑service aware)."""
from __future__ import annotations
import yaml
from pathlib import Path
from typing import Dict, Any, List

class Module:
    """Represents *one directory* that may hold **one or many** services."""

    def __init__(self, yaml_path: Path):
        self.yaml_path = yaml_path
        self.raw: Dict[str, Any] = yaml.safe_load(self.yaml_path.read_text()) or {}
        # folder name is default service/group name
        self.folder_name: str = self.yaml_path.parent.name

    # --------------------------------------------------------------------- helpers
    @staticmethod
    def _normalize_image(img: Any) -> str | None:
        if isinstance(img, str):
            return img
        if isinstance(img, dict):
            repo = img.get("repository")
            tag = img.get("tag", "latest")
            return f"{repo}:{tag}" if repo else None
        return None

    @staticmethod
    def _normalize_env(env: Any) -> List[str]:
        if isinstance(env, list):
            return [f"{e['name']}={e['value']}" for e in env if "name" in e and "value" in e]
        return []

    @staticmethod
    def _normalize_ports(ports: Any) -> List[str]:
        out = []
        for p in ports or []:
            c = p.get("containerPort")
            h = p.get("hostPort", c)
            if c:
                out.append(f"{h}:{c}")
        return out

    @staticmethod
    def _normalize_volumes(volumes: Any) -> List[str]:
        return volumes or []

    # build block
    def _build_block(self, svc_name: str, spec: Dict[str, Any]) -> Dict[str, Any]:
        block = {
            "container_name": svc_name,
            "image": self._normalize_image(spec.get("image")),
            "environment": self._normalize_env(spec.get("env")),
            "ports": self._normalize_ports(spec.get("ports")),
            "volumes": self._normalize_volumes(spec.get("volumes")),
        }
        return {k: v for k, v in block.items() if v}

    # ------------------------------------------------------------------ public API
    def compose_service(self) -> Dict[str, Any]:
        if "services" in self.raw:  # multi-service mode
            result: Dict[str, Any] = {}
            for svc_name, spec in self.raw["services"].items():
                result[svc_name] = self._build_block(svc_name, spec)
            return result
        # single service
        svc_name = self.raw.get("node_name") or self.folder_name
        return {svc_name: self._build_block(svc_name, self.raw)}

    def declared_named_volumes(self) -> List[str]:
        vols: List[str] = []

        def collect(vol_desc: str):
            host = vol_desc.split(":")[0]
            if "/" not in host:
                vols.append(host)

        if "services" in self.raw:
            for spec in self.raw["services"].values():
                for v in self._normalize_volumes(spec.get("volumes")):
                    collect(v)
        else:
            for v in self._normalize_volumes(self.raw.get("volumes")):
                collect(v)
        return vols
