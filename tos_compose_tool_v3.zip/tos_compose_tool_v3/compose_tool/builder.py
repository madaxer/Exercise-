
import yaml
from pathlib import Path
from typing import Dict, Any
from .module import Module

class ComposeBuilder:
    def __init__(self, base_compose: Path):
        self.base_path = base_compose
        self.doc: Dict[str, Any] = yaml.safe_load(self.base_path.read_text()) or {}
        self.doc.setdefault("services", {})

    def add_module(self, module: Module):
        self.doc["services"].update(module.compose_service())

    def dump(self) -> str:
        return yaml.dump(self.doc, sort_keys=False)
