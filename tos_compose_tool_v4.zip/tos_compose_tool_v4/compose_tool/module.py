
from __future__ import annotations
import yaml, os, re
from dotenv import load_dotenv
from pathlib import Path
from typing import Dict, Any, List

class Module:
    def __init__(self, yaml_path: Path):
        self.yaml_path = yaml_path
        load_dotenv(dotenv_path=self.yaml_path.parent.parent / ".env")
        with open(self.yaml_path) as f:
            raw_data = yaml.safe_load(f)
            self.raw = self._resolve_env_vars(raw_data or {})
        self.folder_name: str = self.yaml_path.parent.name

    def _resolve_env_vars(self, obj: Any) -> Any:
        pattern = re.compile(r"\${(.*?)}")
        if isinstance(obj, dict):
            return {k: self._resolve_env_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._resolve_env_vars(i) for i in obj]
        elif isinstance(obj, str):
            def repl(match): return os.getenv(match.group(1), match.group(0))
            return pattern.sub(repl, obj)
        return obj

    def _normalize_image(self, img: Any) -> str | None:
        if isinstance(img, str): return img
        if isinstance(img, dict):
            repo = img.get("repository")
            tag = img.get("tag", "latest")
            return f"{repo}:{tag}" if repo else None
        return None

    def _normalize_env(self, env: Any) -> List[str]:
        return [f"{e['name']}={e['value']}" for e in env or [] if "name" in e and "value" in e]

    def _normalize_ports(self, ports: Any) -> List[str]:
        out = []
        for p in ports or []:
            c = p.get("containerPort")
            h = p.get("hostPort", c)
            if c: out.append(f"{h}:{c}")
        return out

    def _normalize_volumes(self, volumes: Any) -> List[str]:
        return volumes or []

    def _build_block(self, svc_name: str, spec: Dict[str, Any]) -> Dict[str, Any]:
        block = {
            "container_name": svc_name,
            "image": self._normalize_image(spec.get("image") or self.raw.get("image")),
            "environment": self._normalize_env(spec.get("env")),
            "env_file": spec.get("env_file"),
            "ports": self._normalize_ports(spec.get("ports")),
            "volumes": self._normalize_volumes(spec.get("volumes")),
        }
        return {k: v for k, v in block.items() if v}

    def compose_service(self) -> Dict[str, Any]:
        if "services" in self.raw:
            return {svc_name: self._build_block(svc_name, spec)
                    for svc_name, spec in self.raw["services"].items()}
        svc_name = self.raw.get("node_name") or self.folder_name
        return {svc_name: self._build_block(svc_name, self.raw)}

    def declared_named_volumes(self) -> List[str]:
        vols = []
        def collect(vol_desc: str):
            host = vol_desc.split(":")[0]
            if "/" not in host: vols.append(host)
        if "services" in self.raw:
            for spec in self.raw["services"].values():
                for v in self._normalize_volumes(spec.get("volumes")): collect(v)
        else:
            for v in self._normalize_volumes(self.raw.get("volumes")): collect(v)
        return vols
