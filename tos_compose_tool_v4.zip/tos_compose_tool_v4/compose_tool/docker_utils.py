
import subprocess, sys
from typing import List
try:
    import docker  # type: ignore
except ImportError:
    docker = None

def create_named_volumes(names: List[str]):
    if not names: return
    if docker is None:
        print("⚠ docker SDK not installed, skipping volume creation", file=sys.stderr)
        return
    client = docker.from_env()
    existing = {v.name for v in client.volumes.list()}
    for v in names:
        if v not in existing:
            print(f"Creating volume {v}")
            client.volumes.create(name=v)

def run_compose(compose_file: str, action: str = "up", detach: bool = True):
    cmd = ["docker", "compose", "-f", compose_file, action]
    if action == "up" and detach:
        cmd.append("-d")
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True)
