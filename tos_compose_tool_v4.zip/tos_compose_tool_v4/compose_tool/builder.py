
import yaml
from pathlib import Path
from typing import Dict, Any
from .module import Module

class ComposeBuilder:
    def __init__(self, base_compose: Path):
        self.base_path = base_compose
        self.doc: Dict[str, Any] = yaml.safe_load(self.base_path.read_text()) or {}
        self.doc.setdefault("services", {})

    def _insert_anchor(self):
        base = {
            "env_file": ["./env/common.env"],
            "volumes": ["log:/tos/log:subpath=log,nocopy=true"],
            "restart": "always"
        }
        self.doc["x-base-template"] = { "&module-base": base }

    def add_module(self, module: Module):
        new_svcs = module.compose_service()
        for name, spec in new_svcs.items():
            spec.setdefault("<<", "*module-base")
            self.doc["services"][name] = spec

    def dump(self) -> str:
        self._insert_anchor()
        return yaml.dump(self.doc, sort_keys=False)
